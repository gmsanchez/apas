function v = using_matlab()

% using_matlab - return 1 for Matlab, 0 for Scilab

v = 1;